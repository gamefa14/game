#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eth-eu2.nanopool.org:9999
WALLET=0xce9e74a3a1b56afe24801e3e46dbda66bd3401a7.lolMinerWorker

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./algo --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./algo --algo ETHASH --pool $POOL --user $WALLET $@
done
